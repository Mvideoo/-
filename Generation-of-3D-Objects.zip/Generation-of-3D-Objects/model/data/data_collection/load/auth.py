__API_TOKEN = ""


def set_api_token(api_token):
    global __API_TOKEN
    __API_TOKEN = api_token
    print("Set API Token")
